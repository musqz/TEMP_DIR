---
title: Desktop widgets in Mabox Noctalia CE
tags: [mabox, noctalia, desktop-widgets, luau, plugins]
created: 2026-11-18
updated: 2026-11-18
---

# Desktop widgets in Mabox Noctalia CE

How the Mabox desktop widgets (Info, Sysinfo, Todo today, Polaroids) are written. They are Noctalia plugins in Luau: a `plugin.toml` declares them, one script draws them. The files are in `files/`; every path below is relative to this folder.

Source repo: `github.com/musqz/mabox-noctalia-ce`, folder `configs/mabox-noctalia-ce/plugins/`. The package installs the plugins to `/usr/share/mabox-noctalia-ce/plugins`.

## Files

```
files/
├── bin
│   └── mb-widget
├── configs-panel
│   └── widgetradius.luau
└── plugins
    ├── info
    │   ├── info.luau
    │   ├── lib
    │   │   ├── celogo.luau
    │   │   └── fs.luau
    │   ├── plugin.toml
    │   └── translations
    │       └── en.json
    ├── polaroids
    │   ├── plugin.toml
    │   ├── translations
    │   │   └── en.json
    │   └── widget.luau
    ├── sysinfo
    │   ├── lib
    │   │   ├── celogo.luau
    │   │   └── fs.luau
    │   ├── plugin.toml
    │   ├── translations
    │   │   └── en.json
    │   └── widget.luau
    └── todo
        ├── lib
        │   ├── celogo.luau
        │   ├── fs.luau
        │   ├── hotkey.luau
        │   ├── today.luau
        │   └── todo.luau
        ├── panel.luau
        ├── plugin.toml
        ├── translations
        │   └── en.json
        └── widget.luau
```

- `files/plugins/info`: logo, About line and the basic hotkeys. The smallest widget, a good start.
- `files/plugins/sysinfo`: date, system info, CPU and RAM graphs, top processes, discs, updates.
- `files/plugins/todo`: the *Todo today* widget (`widget.luau`) and the Todo panel (`panel.luau`). The widget only reads; `lib/today.luau` is a trimmed copy of the parser in `lib/todo.luau`.
- `files/plugins/polaroids`: the previous or random wallpapers as polaroids.
- `files/bin/mb-widget`: shell script that shows or hides one widget by name.
- `files/configs-panel/widgetradius.luau`: part of the Configs panel; it finds the placed widgets in the state file and writes their settings with `config-set` (the *Corner radius* control).

## A widget in three files

1. **`plugin.toml`** declares the plugin and its widget:
   - `id = "mabox/info"`, `plugin_api = 43`.
   - `[[desktop_widget]]` with `id` and `entry` (the script).
   - Optional `[[desktop_widget.setting]]` blocks: `key`, `type` (`int`, `bool`), `label_key`, `description_key`, `default`, `min`, `max`. The host draws them in the widget settings.
2. **The entry script** (`info.luau`, `widget.luau`) draws the widget.
3. **`translations/en.json`** holds the texts for `label_key` and `description_key` (`settings.<key>.label`).

### Settings of the Mabox widgets

| Widget | Settings (key, type, range) |
|---|---|
| Info, Sysinfo | `size` int 50-200 (Text size, percent), `radius` int 0-32 (Corner radius) |
| Todo today | `max` int 3-15 (tasks shown), `size`, `radius` |
| Polaroids | `count` int 1-8, `random` bool |

A setting is declared once in `plugin.toml`, shown by Noctalia's settings editor, and read with `noctalia.getConfig("key")` in the script. Setting types Noctalia knows: `string`, `string_list`, `string_map`, `bool`, `int`, `double`, `select`, `file`, `folder`, `glyph`, `color`. Fields: `key`, `type`, `label_key`, `description_key`, `default`, `min`/`max` (int, double), `options` (select), `visible_when`, `advanced`. We only use `int` and `bool`. Full table: `manifest.mdx`, section "Settings schema", in the Noctalia docs.


A widget id is written `plugin-id:widget-id`, for example `mabox/info:info`.

## The entry script

Three globals exist in a desktop-widget script: `ui` (controls), `noctalia` (runtime) and `desktopWidget`.

```lua
--!nonstrict
local function render()
  desktopWidget.render(ui.column({ gap = 3, padding = 10, fill = "surface/0.85", radius = 8, border = "outline", borderWidth = 1 }, {
    ui.label({ text = "Hello", fontSize = 12, color = "primary" }),
  }))
end

function update() render() end            -- runs on the update interval
function onConfigChanged() render() end   -- a widget setting changed

noctalia.setUpdateInterval(5000)          -- milliseconds
desktopWidget.setWantsSecondTicks(false)
render()
```

(The sketch follows `files/plugins/info/info.luau`; it was not run on its own.)

- `desktopWidget.render(tree)` hands the whole `ui.*` tree to the host. Noctalia compares it with the previous one and updates the controls in place.
- `update()` runs every `noctalia.setUpdateInterval(ms)` (default 1000). Each widget here keeps its own counter (`ticks`) to run slow work less often: Info reloads the key list every 36 ticks, Sysinfo reads the processes every 2nd tick and the static info every 300th.
- `noctalia.getConfig("key")` reads a widget setting (see `todo/widget.luau`, `max`).
- **Position, size and rotation belong to the host.** The user places the widget in the desktop widgets editor; the script only draws its content.
- Colors are theme tokens: `primary`, `on_surface`, `on_surface_variant`, `outline`, `outline_variant`, `tertiary`, `surface_variant`, `surface/0.85` (token with alpha). The widgets follow the wallpaper palette this way.

## Controls used

`ui.column`, `ui.row`, `ui.box`, `ui.label`, `ui.separator`, `ui.button` (Todo header), `ui.graph` and `ui.progress` (Sysinfo), `ui.image` (Polaroids; local files only). Interactive controls like `ui.input` are for panels, not desktop widgets. Desktop widgets show no tooltips.

## Data and shell calls

- A callback may use about 25 ms of CPU. Anything slower (parsing a big file, running `top`, `magick`) goes through `noctalia.runAsync({ "cmd", ... }, function(result) ... end)`; `result.stdout` and `result.exitCode` arrive later. Examples: `sysinfo/widget.luau` (`PROC_CMD`, `STATIC_CMD`), `info/info.luau` (`mb-keys list --tsv`).
- Files: `noctalia.readFile`, `writeFile`, `removeFile`, `fileExists`, `mkdirAll`, `pluginDataDir()` (the plugin's own data folder), `getenv`.
- `noctalia.systemStats()` gives CPU and RAM (Sysinfo).

| Widget | Source of its data | Update |
|---|---|---|
| Info | `mb-keys list --tsv` (the basic hotkeys) | 5 s, keys every 36 ticks |
| Sysinfo | `noctalia.systemStats()`, `top`, `df`, `pacman -Q`, `/sys` battery, update counts from `$XDG_RUNTIME_DIR/mb-updates` | 2 s |
| Todo today | `~/.todo/*.txt` (todo.txt, `due:` dates) through `lib/today.luau` | 10 s; a click on the header opens the panel (`noctalia msg panel-toggle mabox/todo:main`) |
| Polaroids | history file in the plugin data folder, polled from `noctalia msg wallpaper-get`; random mode lists the wallpaper folder; thumbnails with `magick` | see `polaroids/widget.luau` |

## Text size

Info, Sysinfo and Todo have a *Text size* setting (percent). `lib/fs.luau` turns a base size into the real one: the setting divided by Noctalia's global `accessibility.ui_scale`, so the global scale of the shell does not shrink the widgets. `fs(11)` replaces `11` in `fontSize`, `width`, `height` and logo sizes. The file is the same in every plugin (`lib/` is per plugin).

## Corner radius and the host background

Two radii exist and they are independent:

- **The card the script draws.** Info, Sysinfo and Todo draw a card as the root `ui.column` (`fill = "surface/0.85"`, `radius`, `border = "outline"`). Its `radius` is the widget setting `radius` (`math.max(0, math.min(32, tonumber(noctalia.getConfig("radius")) or 8))`).
- **The host background rectangle.** Noctalia gives every desktop widget the common settings `background`, `background_color`, `background_opacity`, `background_radius` (default 12) and `background_padding` (default 10). Plugins do not declare them. They live in the same `.settings` table in the state file and are edited in the widget editor. See `docs/user/desktop/widgets.mdx` ("Common settings") in the Noctalia docs. Our widgets run with `background_opacity = 0.0`, so only the script card shows.

The Configs panel (*Widgets* card, *Corner radius*) sets `radius` for all placed Mabox widgets or one kind at a time:

```sh
noctalia msg config-set desktop_widgets.widget.<id>.settings.radius 16
```

`config-set` only accepts keys the plugin declared: a widget without `radius` (Polaroids) answers "unknown setting". `files/configs-panel/widgetradius.luau` shows how to find the widget ids and types in the state file and loop over them.

## Where the host keeps the layout

Placement lives in Noctalia's state file `~/.local/state/noctalia/settings.toml`, which overrides `config.toml`:

```toml
[desktop_widgets]
enabled = true

[desktop_widgets.widget.desktop-widget-0000000000000005]
type = 'mabox/info:info'
enabled = true
output = 'HDMI-A-2'
cx = 284.0
cy = 1111.0
box_width = 384.0
box_height = 504.0
rotation = 0.0

    [desktop_widgets.widget.desktop-widget-0000000000000005.settings]
    size = 100
```

(The values are from one machine; the keys are what matters.) Read and write with `noctalia msg config-get desktop_widgets.widget` and `config-set`; do not edit the file while Noctalia runs.

## Turn widgets on and off

- `[desktop_widgets] enabled = true` in `configs/noctalia/config.toml` switches the feature on.
- `noctalia msg desktop-widgets-edit` opens the editor to add, place and resize widgets (the add list shows the plugin widgets by name). `desktop-widgets-exit` closes it.
- The Configs panel, *Widgets* card, has an *Edit layout* button for the same editor (`desktop-widgets-toggle-edit`).
- `W-A-d` runs `noctalia msg desktop-widgets-toggle`: show or hide all widgets (runtime only).
- `files/bin/mb-widget [toggle|on|off] <name>`: show or hide one widget by name; with no argument it lists them. It reads `noctalia msg config-get desktop_widgets.widget` and ignores entries whose plugin is disabled.

## Develop and test

- Plugin source: the `mabox` source points at `/usr/share/mabox-noctalia-ce/plugins` (`noctalia msg plugins source add mabox path ...`, done in `autostart`). A developer can point a source at a git clone instead.
- Reload after an edit: `noctalia msg plugins disable mabox/info; noctalia msg plugins enable mabox/info`.
- Errors: `~/.cache/noctalia/noctalia.log`, look for `[ERR] [luau]`. A widget that draws nothing usually has a Luau error or a bad control.

## Pitfalls we hit

- A retained, keyed `ui.box` keeps an old `border` if a later render leaves it out. Send `border` and `borderWidth` every time (`borderWidth = 0` when off).
- Never put `nil` in the middle of a children table; insert conditionally.
- Give list children a `key` so a reorder reuses the same controls.
- Keep slow work out of `update()` and `render()`: past about 25 ms CPU Noctalia disables the panel or widget after repeated timeouts.
- `ui.image` loads local files only.
- A `width` on `ui.label` is ignored. Wrap the label in `ui.column({ width = 56 })`, or give it `flexGrow = 1` and right-align the controls next to it.

## Reference

Noctalia's own plugin docs, in the Noctalia repository under `docs/user/plugins/development/`: `declarative-ui.mdx` (the `desktopWidget.*` section and all `ui.*` controls), `entries.mdx` (entry functions), `manifest.mdx` (`[[desktop_widget]]`), `runtime-api.mdx` (`noctalia.*`). The official `noctalia/timer` plugin is their reference desktop widget.
